<?php
    $date = date('H:i:s d-m-Y');
    print "
    $date
    ";        
?>